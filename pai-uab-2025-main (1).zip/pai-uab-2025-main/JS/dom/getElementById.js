// Selecciona el elemento con ID 'uniqueElement'
let uniqueElement = document.getElementById("uniqueElement");
//A quién?¿ al div REF.
uniqueElement.style.backgroundColor = "yellow";
//Acción al div con id='uniqueElement'

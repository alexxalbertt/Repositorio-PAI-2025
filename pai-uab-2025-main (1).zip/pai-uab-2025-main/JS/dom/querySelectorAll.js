// Selecciona todos los elementos <li>
let listItems = document.querySelectorAll('ul li');
listItems.forEach(item => {
  item.style.color = 'green';
});

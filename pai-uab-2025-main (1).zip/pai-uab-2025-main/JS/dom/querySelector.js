// Selecciona el primer elemento <p> dentro de .container
let paragraph = document.querySelector('.container .text');
paragraph.style.fontWeight = 'bold';

// Selecciona todos los elementos con clase 'item'
let items = document.getElementsByClassName("item");
for (let i = 0; i < items.length; i++) {
  items[i].style.border = "1px solid red";
}

// Vull canviar el text del segon element
// items[1].innerHTML = "Aquest és el segon";

// Vull tatxar el tercer element
// items[2].style.textDecoration = "line-through";

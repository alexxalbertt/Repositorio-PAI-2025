// Selecciona todos los elementos <h2>
let subtitles = document.getElementsByTagName("h2");
for (let i = 0; i < subtitles.length-1; i++) {
  subtitles[i].style.color = "blue";
}

// console.log(subtitles.length);

// subtitles[0].style.color = "blue";

// subtitles[1].style.color = "red";

// subtitles[2].style.color = "green";
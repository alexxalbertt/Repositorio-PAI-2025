console.log("Inici del bucle while.");

let contador = 5;
while (contador >= 5) {
  console.log("El valor de contador és: " + contador);
  contador++;
}

console.log("Bucle while finalitzat.");
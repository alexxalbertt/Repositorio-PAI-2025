// Exercici 1 repeteix "Estem fent bucles 10 vegades"
// for
for (let i = 0; i < 10; i++) {
    console.log("Estem fent bucles for");
}

// while
let i =0;
while (i < 10) {
    console.log("Estem fent bucles while");
    i++;
}

// do while
let j =0;
do {
    console.log("Estem fent bucles dowhile");
    j++;
} while (j < 10);

//Exercici 2: mostra del 5 al 20

// for
for (let i = 5; i <= 20; i++) {
    console.log(i);
}

// while
let x =5;
while (x <= 20) {
    console.log(x);
    x++;
}

// do while
let y = 5;
do {
    console.log(y);
    y++;
} while (y <= 20);
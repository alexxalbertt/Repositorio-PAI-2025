// 21.1.- Fes un programa que faci el següent: ● Defineix una variable de tipus array, buida. ● Afegeixi el valor “Hola” a la posició 0. ● Afegeixi el valor “Adeu” a la posició 1. ● Escrigui a la consola el contingut de la taula.

let array = []; 

array[0]= "Hola";
array[1]= "Adeu";

// array = ["Hola", "Adeu"];

console.log(array);
alert(array);

// document.getElementById("resultado211").innerHTML = "El primer valor es " + array[0] + " i el segon valor es " + array[1];
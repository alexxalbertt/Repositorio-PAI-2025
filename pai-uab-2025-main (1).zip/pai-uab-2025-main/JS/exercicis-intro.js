// 2.1.- Què passaria si féssim aquestes declaracions de variables? Pensa primer que creus que passaria. Després pots provar a executar aquestes instruccions i veure que passa (si passa alguna cosa). 

var a = 1; // a és igual a 1
//1000 linies de codi 
var a = 2; // a és igual a 2
console.log(a); 

// var b = 1;
// //1000 linies de codi 
// let b = 2; 
// // Uncaught SyntaxError: Identifier 'a' has already been declared
// console.log(b);

// let c = 1; 
// var c = 2; 
// console.log(c); 

// let d = 1; 
// let d = 2; 
// console.log(d); 
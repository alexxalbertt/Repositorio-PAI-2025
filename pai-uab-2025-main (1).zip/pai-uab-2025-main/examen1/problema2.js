const diaSetmana = 3;

switch (diaSetmana) {
  case 1:
    console.log("dilluns");
    break;
  case 2:
    console.log("dimarts");
    break;
  case 3:
    console.log("dimecres");
    break;
  case 4:
    console.log("dijous");
    break;
  case 5:
    console.log("divendres");
    break;
  case 6:
    console.log("dissabte");
    break;
  case 7:
    console.log("diumenge");
    break;
  default:
    console.log("Dia no vàlid");
}
